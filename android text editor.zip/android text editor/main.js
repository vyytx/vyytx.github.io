var _width = innerWidth;
var _height = innerHeight;

var word = {
    h: _width*0.05,
    w: _width*0.05*5/9
}

var text = new $("#text");
var number = new $("#number");

var start = text.prop("selectionStart");
var end = text.prop("selectionEnd");
var now = -1;

var key = {};

preinit();

text.on("keydown", function(e){
    key[e.keyCode] = true;

    var t = text.val();
    var row_now = t.substr(0, now).split('\n').length;
    var text_b = t.substr(0, now);
    var text_a = t.substr(now, t.length);
    start = text.prop("selectionStart");
    end = text.prop("selectionEnd");
    if(start == end)
        now = start;
    else
        now = -1;

    if(key[13]){
        var line = getLine();
        number.append("<div class='number'>"+line+"</div>");
        text.scrollTop(text[0].scrollHeight);
    }
    if(key[8] && t[now-1] == '\n'){
        $('.number').last().remove();
    }
    if(key[9]){
        text.val(t + "\t");
    }
    return true;
}).on("keyup", function(e){
    key[e.keyCode] = false;
}).on("blur", function(){
    start = text.prop("selectionStart");
    end = text.prop("selectionEnd");
    if(start == end)
        now = start;
    else
        now = -1;
}).scroll(function(){
    var scroll = text[0].scrollTop;
    number.scrollTop(scroll);
});

number.scroll(function(){
    var scroll = text[0].scrollTop;
    text.scrollTop(scroll);
});

$('body').on('click', '.number', function(){
    var line = $(this).text();
    $('.number').removeClass('sel');
    $(this).addClass('sel');
    selLine(text[0], line);
});

$('body').on('click', '.sel', function(){
    $(this).removeClass('sel');
    text.prop("selectionStart", 0);
    text.prop("selectionEnd", 0);
});

$('#copy').on('click', function(){
    var t = text.val();
    var t_sub = t.substr(start, end-start);
    if(t_sub != "" && t_sub != undefined){
        copyToClipboard(t_sub);
        alert("Copied!");
    }
})

function copyToClipboard(text) {
    if (window.clipboardData && window.clipboardData.setData) {
        // IE specific code path to prevent textarea being shown while dialog is visible.
        return clipboardData.setData("Text", text); 

    } else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
        var textarea = document.createElement("textarea");
        textarea.textContent = text;
        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
        document.body.appendChild(textarea);
        textarea.select();
        try {
            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
        } catch (ex) {
            console.warn("Copy to clipboard failed.", ex);
            return false;
        } finally {
            document.body.removeChild(textarea);
        }
    }
}

function selLine(tarea,lineNum) {
    lineNum--; // array starts at 0
    var lines = tarea.value.split("\n");
    var startPos = 0, endPos = tarea.value.length;
    for(var x = 0; x < lines.length; x++) {
        if(x == lineNum) {
            break;
        }
        startPos += (lines[x].length+1);

    }
    var endPos = lines[lineNum].length+startPos;
    if(typeof(tarea.selectionStart) != "undefined") {
        tarea.focus();
        tarea.selectionStart = startPos;
        tarea.selectionEnd = endPos;
        return true;
    }

    return false;
}

function getLine(){
    var last = $('.number').last();
    return last.text()/1+1;
}

function preinit(){
    $('#text, #number').attr("style", `font: ` + Math.floor(word.h) + `px Arial !important`);
    number.append("<div class='number'>1</div>");
}