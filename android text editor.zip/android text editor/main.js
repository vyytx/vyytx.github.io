var _width = innerWidth;
var _height = innerHeight;

var word = {
    h: _width*0.04,
    w: _width*0.04*5/9
}

var text = new $("#text");
var number = new $("#number");

var key = {};

preinit();

text.on("keydown", function(e){
    key[e.keyCode] = true;

    var t = text.val();
    var now = text[0].selectionStart;
    var row_now = t.substr(0, now).split('\n').length;
    var text_b = t.substr(0, now);
    var text_a = t.substr(now, t.length);

    if(key[13]){
        var line = getLine();
        number.append("<div class='number'>"+line+"</div>");
        text.scrollTop(text[0].scrollHeight);
    }
    if(key[8] && t[now-1] == '\n'){
        $('.number').last().remove();
    }
    if(key[9]){
        text.val(t + "\t");
    }
    if (key[16] && key[188]) {
        text.val(text_b + "<>" + text_a);
        text[0].selectionStart--;
        text[0].selectionStop--;
        return false;
    }
    return true;
});

text.on("keyup", function(e){
    key[e.keyCode] = false;
});

text.scroll(function(){
    var scroll = text[0].scrollTop;
    number.scrollTop(scroll);
});

number.scroll(function(){
    var scroll = text[0].scrollTop;
    text.scrollTop(scroll);
});

function getLine(){
    var t = text.val();
    return t.substr(0, t.selectionStart).split("\n").length+1;
}

function preinit(){
    $('#text, #number').attr("style", `font: ` + Math.floor(word.h) + `px Arial !important`);
    number.append("<div class='number'>1</div>");
}