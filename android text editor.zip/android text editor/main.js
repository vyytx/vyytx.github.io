var _width = innerWidth;
var _height = innerHeight;

var word = {
    h: _width*0.04,
    w: _width*0.04*5/9
}

var text = new $("#text");
var number = new $("#number");

preinit();

text.on("keydown", function(){
    var key = window.event.keyCode;

    if(key == 13){
        text.val(text.val()+'\n');
        var line = getLine();
        number.append("<div class='number'>"+line+"</div>");
        text.scrollTop(text[0].scrollHeight);
        return false;
    }else if(key == 8 && text.val()[text.val().length-1] == '\n'){
        $('.number').last().remove();
        text.val().pop();
        return true;
    }else{
        return true;
    }
});

text.scroll(function(){
    var scroll = text[0].scrollTop;
    number.scrollTop(scroll);
});

number.scroll(function(){
    var scroll = text[0].scrollTop;
    text.scrollTop(scroll);
});

function getLine(){
    var t = text.val();
    return t.substr(0, t.selectionStart).split("\n").length;
}

function preinit(){
    $('#text, #number').attr("style", `font: ` + Math.floor(word.h) + `px Arial !important`);
    number.append("<div class='number'>1</div>");
}